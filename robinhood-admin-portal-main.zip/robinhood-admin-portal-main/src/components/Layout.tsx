
import { Outlet } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import { useState, useEffect } from "react";

const Layout = () => {
  const [notification, setNotification] = useState<string | null>(null);
  
  useEffect(() => {
    // Check for notifications in localStorage (simulating persistent notifications)
    const storedNotification = localStorage.getItem("govNotification");
    if (storedNotification) {
      setNotification(storedNotification);
    }
  }, []);
  
  const dismissNotification = () => {
    localStorage.removeItem("govNotification");
    setNotification(null);
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      {notification && (
        <div className="gov-alert flex justify-between items-center">
          <div>{notification}</div>
          <button 
            onClick={dismissNotification} 
            className="text-gov-red hover:text-red-700"
            aria-label="Dismiss notification"
          >
            ×
          </button>
        </div>
      )}
      
      <main className="flex-grow">
        <div className="gov-container">
          <Outlet />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Layout;
