
import { Link, useLocation } from "react-router-dom";

const Header = () => {
  const location = useLocation();
  
  return (
    <header>
      <div className="gov-header">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center">
            <Link to="/" className="text-xl md:text-2xl font-bold">
              Robinhood Admin Portal
            </Link>
          </div>
          
          <nav className="hidden md:block">
            <ul className="flex space-x-6">
              <li>
                <Link 
                  to="/"
                  className={`hover:underline ${location.pathname === '/' ? 'font-bold' : ''}`}
                >
                  Home
                </Link>
              </li>
              <li>
                <Link 
                  to="/dashboard"
                  className={`hover:underline ${location.pathname === '/dashboard' ? 'font-bold' : ''}`}
                >
                  Dashboard
                </Link>
              </li>
              <li>
                <Link 
                  to="/add-user"
                  className={`hover:underline ${location.pathname === '/add-user' ? 'font-bold' : ''}`}
                >
                  Add User
                </Link>
              </li>
            </ul>
          </nav>
          
          <div className="md:hidden">
            <select 
              onChange={(e) => {
                window.location.href = e.target.value;
              }}
              value={location.pathname}
              className="bg-transparent text-white border border-white rounded py-1 px-2"
            >
              <option value="/" className="text-black">Home</option>
              <option value="/dashboard" className="text-black">Dashboard</option>
              <option value="/add-user" className="text-black">Add User</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="bg-gov-light py-2 px-4 md:px-8 border-b border-gray-300">
        <div className="max-w-7xl mx-auto">
          <div className="text-sm text-gov-gray">
            {location.pathname === '/' && "Home"}
            {location.pathname === '/dashboard' && "Dashboard > All Users"}
            {location.pathname === '/add-user' && "Dashboard > Add New User"}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
