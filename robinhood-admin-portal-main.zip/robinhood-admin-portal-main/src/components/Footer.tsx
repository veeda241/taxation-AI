
const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="gov-footer">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-3">Robinhood Admin Portal</h3>
            <p className="text-sm text-gray-300">
              Official administration system for managing user data and monitoring suspicious activities.
            </p>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-3">Important Links</h3>
            <ul className="text-sm space-y-2">
              <li><a href="#" className="hover:underline">Privacy Policy</a></li>
              <li><a href="#" className="hover:underline">Terms of Service</a></li>
              <li><a href="#" className="hover:underline">Security Information</a></li>
              <li><a href="#" className="hover:underline">Accessibility</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-3">Contact</h3>
            <ul className="text-sm space-y-2">
              <li>admin@robinhood-gov.example</li>
              <li>1-800-ROBIN-HELP</li>
              <li>123 Government Street</li>
              <li>Washington, DC 20001</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-4 border-t border-blue-800 text-sm text-center md:text-left">
          <p>© {currentYear} Robinhood Administration System. All rights reserved.</p>
          <p className="mt-1 text-gray-300 text-xs">This is an official government website.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
