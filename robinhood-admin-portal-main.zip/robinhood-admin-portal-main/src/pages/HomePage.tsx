
import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <div className="space-y-8">
      <section className="text-center py-10 px-4">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
          Welcome to Robinhood
        </h1>
        <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8 text-gray-600">
          Official administration portal for managing financial distribution programs 
          and monitoring user activities to ensure fair and equitable access to resources.
        </p>
        <Link to="/dashboard" className="gov-button text-lg">
          Go to Dashboard
        </Link>
      </section>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
        <div className="gov-card">
          <h3 className="text-xl font-bold mb-3">User Management</h3>
          <p className="text-gray-600 mb-4">
            Register new users, view user profiles, and manage financial data all in one centralized location.
          </p>
          <Link to="/dashboard" className="text-gov-blue hover:underline font-medium">
            View All Users →
          </Link>
        </div>
        
        <div className="gov-card">
          <h3 className="text-xl font-bold mb-3">Suspicious Activity</h3>
          <p className="text-gray-600 mb-4">
            Flag suspicious user behavior for further investigation and track potentially fraudulent activities.
          </p>
          <Link to="/dashboard" className="text-gov-blue hover:underline font-medium">
            Monitor Activity →
          </Link>
        </div>
        
        <div className="gov-card">
          <h3 className="text-xl font-bold mb-3">Add New Users</h3>
          <p className="text-gray-600 mb-4">
            Quickly add new users to the system with our streamlined registration process.
          </p>
          <Link to="/add-user" className="text-gov-blue hover:underline font-medium">
            Register User →
          </Link>
        </div>
      </div>
      
      <section className="mt-12 bg-gov-light p-6 rounded">
        <h2 className="text-2xl font-bold mb-4">About the Robinhood Program</h2>
        <p className="text-gray-700 mb-4">
          The Robinhood Program is designed to provide financial assistance to eligible citizens based on income level 
          and financial need. Our administration portal helps maintain the integrity of the program through comprehensive 
          user management and fraud detection systems.
        </p>
        <p className="text-gray-700">
          For authorized personnel only. Unauthorized access is strictly prohibited and subject to legal action.
        </p>
      </section>
    </div>
  );
};

export default HomePage;
