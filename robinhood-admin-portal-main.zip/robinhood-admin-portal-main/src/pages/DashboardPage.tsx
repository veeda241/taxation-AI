
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

interface User {
  id: string;
  name: string;
  income: number;
  dateAdded: string;
  status: string;
  flagged: boolean;
}

const DashboardPage = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterFlagged, setFilterFlagged] = useState(false);
  
  // Mock API call to get users
  useEffect(() => {
    // Simulate API fetch delay
    const fetchUsers = async () => {
      try {
        setLoading(true);
        // In a real app, this would be:
        // const response = await fetch('/api/users');
        // const data = await response.json();
        
        // For now, simulate data
        setTimeout(() => {
          const mockUsers: User[] = [
            { 
              id: "USR-001", 
              name: "John Smith", 
              income: 45000, 
              dateAdded: "2025-03-15", 
              status: "Active",
              flagged: false
            },
            { 
              id: "USR-002", 
              name: "Jane Doe", 
              income: 38000, 
              dateAdded: "2025-03-18", 
              status: "Under Review",
              flagged: true
            },
            { 
              id: "USR-003", 
              name: "Robert Johnson", 
              income: 72000, 
              dateAdded: "2025-03-22", 
              status: "Active",
              flagged: false
            },
            { 
              id: "USR-004", 
              name: "Sarah Williams", 
              income: 29000, 
              dateAdded: "2025-04-02", 
              status: "Active",
              flagged: false
            },
            { 
              id: "USR-005", 
              name: "Michael Brown", 
              income: 52000, 
              dateAdded: "2025-04-10", 
              status: "Inactive",
              flagged: false
            },
          ];
          
          setUsers(mockUsers);
          setLoading(false);
        }, 1000);
      } catch (err) {
        setError("Failed to fetch users. Please try again later.");
        setLoading(false);
        console.error("Error fetching users:", err);
      }
    };
    
    fetchUsers();
  }, []);
  
  const handleFlagUser = async (userId: string) => {
    // In a real app, this would be:
    // try {
    //   const response = await fetch(`/api/users/flag/${userId}`, { method: 'PUT' });
    //   if (!response.ok) throw new Error('Failed to flag user');
    //   // Update UI after successful flagging
    // } catch (err) {
    //   console.error(err);
    //   toast.error('Failed to flag user. Please try again.');
    // }
    
    // For now, just update the local state
    setUsers(users.map(user => 
      user.id === userId ? { ...user, flagged: !user.flagged } : user
    ));
    
    const flaggedUser = users.find(user => user.id === userId);
    if (flaggedUser) {
      if (!flaggedUser.flagged) {
        toast.success(`User ${userId} has been flagged as suspicious`);
        // Store a notification in localStorage to simulate persistence
        localStorage.setItem("govNotification", `ALERT: User ${userId} (${flaggedUser.name}) has been flagged for suspicious activity.`);
      } else {
        toast.success(`Flag removed from user ${userId}`);
        localStorage.removeItem("govNotification");
      }
    }
  };
  
  const displayedUsers = filterFlagged 
    ? users.filter(user => user.flagged) 
    : users;
  
  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Dashboard: All Users</h1>
          <p className="text-gray-600">
            Manage users and monitor for suspicious activity
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 mt-4 md:mt-0">
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="flaggedFilter" 
              className="mr-2 h-4 w-4"
              checked={filterFlagged}
              onChange={() => setFilterFlagged(!filterFlagged)}
            />
            <label htmlFor="flaggedFilter">Show only flagged</label>
          </div>
          <Link to="/add-user" className="gov-button">
            Add New User
          </Link>
        </div>
      </div>
      
      {error && (
        <div className="gov-alert mb-6">
          {error}
        </div>
      )}
      
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-pulse text-xl">Loading users...</div>
        </div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="gov-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Income</th>
                  <th>Date Added</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {displayedUsers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-4">
                      {filterFlagged 
                        ? "No flagged users found" 
                        : "No users found"}
                    </td>
                  </tr>
                ) : (
                  displayedUsers.map(user => (
                    <tr key={user.id} className={user.flagged ? "flagged-row" : ""}>
                      <td>{user.id}</td>
                      <td>{user.name}</td>
                      <td>${user.income.toLocaleString()}</td>
                      <td>{user.dateAdded}</td>
                      <td>
                        <span 
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            user.status === 'Active' 
                              ? 'bg-green-100 text-green-800' 
                              : user.status === 'Under Review' 
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {user.status}
                        </span>
                      </td>
                      <td>
                        <button 
                          onClick={() => handleFlagUser(user.id)} 
                          className={user.flagged 
                            ? "bg-gray-500 text-white px-3 py-1 rounded text-sm hover:bg-gray-600" 
                            : "bg-gov-red text-white px-3 py-1 rounded text-sm hover:bg-red-700"}
                        >
                          {user.flagged ? "Remove Flag" : "Flag Suspicious"}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          <div className="mt-8 gov-card">
            <h2 className="text-xl font-semibold mb-4">System Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <p className="font-medium">Total Users:</p>
                <p className="text-2xl font-bold">{users.length}</p>
              </div>
              <div>
                <p className="font-medium">Flagged Users:</p>
                <p className="text-2xl font-bold">{users.filter(u => u.flagged).length}</p>
              </div>
              <div>
                <p className="font-medium">Last Updated:</p>
                <p className="text-lg">{new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default DashboardPage;
