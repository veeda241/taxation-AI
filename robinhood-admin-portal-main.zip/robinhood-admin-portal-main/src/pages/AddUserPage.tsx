
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const AddUserPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    userId: "",
    name: "",
    income: "",
    address: "",
    ssn: "",
    dob: "",
    email: ""
  });
  const [loading, setLoading] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.userId || !formData.name || !formData.income) {
      toast.error("Please fill out all required fields");
      return;
    }
    
    setLoading(true);
    
    // In a real app, this would be:
    // try {
    //   const response = await fetch('/api/users', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify(formData)
    //   });
    //
    //   if (!response.ok) throw new Error('Failed to add user');
    //   toast.success('User added successfully');
    //   navigate('/dashboard');
    // } catch (err) {
    //   console.error(err);
    //   toast.error('Failed to add user. Please try again.');
    // } finally {
    //   setLoading(false);
    // }
    
    // Simulate API call
    setTimeout(() => {
      toast.success("User added successfully");
      setLoading(false);
      navigate("/dashboard");
    }, 1500);
  };
  
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-2">Add New User</h1>
        <p className="text-gray-600">
          Fill out the form below to add a new user to the system
        </p>
      </div>
      
      <div className="gov-card max-w-3xl">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="gov-form-group">
              <label htmlFor="userId" className="gov-label">
                User ID <span className="text-gov-red">*</span>
              </label>
              <input
                type="text"
                id="userId"
                name="userId"
                value={formData.userId}
                onChange={handleChange}
                placeholder="e.g. USR-006"
                required
                className="gov-input"
              />
            </div>
            
            <div className="gov-form-group">
              <label htmlFor="name" className="gov-label">
                Full Name <span className="text-gov-red">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="e.g. John Smith"
                required
                className="gov-input"
              />
            </div>
            
            <div className="gov-form-group">
              <label htmlFor="income" className="gov-label">
                Annual Income <span className="text-gov-red">*</span>
              </label>
              <input
                type="text"
                id="income"
                name="income"
                value={formData.income}
                onChange={handleChange}
                placeholder="e.g. 45000"
                required
                className="gov-input"
              />
            </div>
            
            <div className="gov-form-group">
              <label htmlFor="dob" className="gov-label">Date of Birth</label>
              <input
                type="date"
                id="dob"
                name="dob"
                value={formData.dob}
                onChange={handleChange}
                className="gov-input"
              />
            </div>
            
            <div className="gov-form-group">
              <label htmlFor="ssn" className="gov-label">
                SSN (Last 4 digits)
              </label>
              <input
                type="text"
                id="ssn"
                name="ssn"
                value={formData.ssn}
                onChange={handleChange}
                placeholder="e.g. 1234"
                maxLength={4}
                className="gov-input"
              />
            </div>
            
            <div className="gov-form-group">
              <label htmlFor="email" className="gov-label">Email Address</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="e.g. user@example.com"
                className="gov-input"
              />
            </div>
            
            <div className="gov-form-group md:col-span-2">
              <label htmlFor="address" className="gov-label">Address</label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="e.g. 123 Main St, Anytown, ST 12345"
                className="gov-input"
              />
            </div>
          </div>
          
          <div className="border-t border-gray-200 mt-8 pt-6 flex flex-col sm:flex-row justify-between">
            <button
              type="button"
              onClick={() => navigate("/dashboard")}
              className="gov-button-secondary mb-3 sm:mb-0"
              disabled={loading}
            >
              Cancel
            </button>
            
            <button
              type="submit"
              className="gov-button"
              disabled={loading}
            >
              {loading ? "Adding User..." : "Submit"}
            </button>
          </div>
        </form>
      </div>
      
      <div className="mt-8 text-sm text-gray-500">
        <h3 className="font-semibold mb-2">Important Notes:</h3>
        <ul className="list-disc list-inside space-y-1">
          <li>All fields marked with <span className="text-gov-red">*</span> are required.</li>
          <li>User ID must be unique in the system.</li>
          <li>Income should be reported as annual gross income before taxes.</li>
          <li>All user data is subject to verification procedures.</li>
        </ul>
      </div>
    </div>
  );
};

export default AddUserPage;
